import React from 'react';
export default function Navbar() {
  return (
    <nav className="flex justify-between items-center p-4 shadow bg-white">
      <div className="text-xl font-bold text-blue-600">Faiba</div>
      <ul className="flex gap-6">
        <li><a href="#" className="hover:text-blue-600">Home</a></li>
        <li><a href="#" className="hover:text-blue-600">Products</a></li>
        <li><a href="#" className="hover:text-blue-600">Support</a></li>
        <li><a href="#" className="hover:text-blue-600">Contact</a></li>
      </ul>
    </nav>
  );
}