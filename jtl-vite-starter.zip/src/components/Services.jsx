import React from 'react';
export default function Services() {
  const services = [
    { title: 'Faiba Home', description: 'Reliable fiber internet for your home.' },
    { title: 'Faiba Business', description: 'Dedicated high-speed connections for businesses.' },
    { title: 'Faiba Mobile', description: 'Affordable 4G mobile services.' },
  ];
  return (
    <section className="py-16 px-8 text-center">
      <h2 className="text-3xl font-bold mb-8">Our Services</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {services.map((service) => (
          <div key={service.title} className="border p-6 rounded shadow hover:shadow-lg">
            <h3 className="text-xl font-bold mb-2">{service.title}</h3>
            <p>{service.description}</p>
          </div>
        ))}
      </div>
    </section>
  );
}