import React from 'react';
export default function Hero() {
  return (
    <section className="bg-blue-600 text-white text-center py-24">
      <h1 className="text-4xl font-bold mb-4">Welcome to Jamii Telecommunications</h1>
      <p className="mb-6">Connecting you to fast, reliable internet & mobile solutions.</p>
      <button className="bg-white text-blue-600 px-6 py-3 rounded font-semibold hover:bg-gray-200">
        Explore Packages
      </button>
    </section>
  );
}